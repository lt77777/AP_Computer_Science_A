
/**
This project is to demonstrate the HAS-A and IS-A relationships.
Design an Astroknot class with several instance variables including name, weight, fitnessLevel and currentPlanet. 
The Astroknot will also have several actions it can perform. At the minimum he/she should be able to jump, eat, rest and exercise. 
Note that the fitnessLevel will increase along with a decrease in weight when he/she exercises. Rest could also have an influence on the fitness level. 
Similarly when the astroknot Jumps it’s weight , currentPlanet and fitnessLevel will affect the height of the jump. 
For example Dr. Grateful on the moon will be able to jump much higher than Mr. Mela on Earth even though they have similar fitnessLevels;) 
(I know the moon is not a planet!!) Next you will need to create a class called Planet that creates planet objects that have name, diameter, mass and gravity.
 Remember all of the variables will need to be private so that they may not be changed.

Finally make a client to demonstrate the different aspects of the Astroknot. Send the astroknot to different planets, make them exercise, sleep and jump. Have fun with it!!!
 * Larry Tsai
 * 15DEC2019
 */
public class Astroknot
{
    String name;
    double weight;
    int fitnessLevel;
    String currentPlanet;
    public void setWeight(double weight)
    {
        this.weight=weight;
    }
    public void setWeight(int fitnessLevel)
    {
       this.fitnessLevel=fitnessLevel;
    }
    public void currentPlanet(String Planet)
    {
    this.planet=planet;
}
}