
/**
 * Write a class, Calc, that has 5 methods: add(), subtract(), multiply(), divide(), and modulus(). 
 * Each should receive two parameters, and return the resulting operation.
Next, create a client, CalcTester, that asks the user for two numbers, 
then uses the class to perform and display the first 4 operations. 
(Ask for 2 other numbers for the modulus() operation.)
After this, add a 6th method to Calc: factorial(), which receives one parameter, 
and returns the factorial(example: factorial of 4 = 4*3*2*1 = 24). 
The method must accomplish this by using a loop.
Test this method from the client.
 * 
 * Lawrence Tsai
 * 06DEC2019
 */
public class Calc
{
    
    
    
    int add=0;
    int subtract=0;
    int multiply=0;
    double divide=0;
    int modulus=0;
    
  
   

     public int add(int a,int b)
     {
         int answer=a+b;
         return answer;
        }
         public int subtract(int a,int b)
     {
         int answer=a-b;
         return answer;
        }
         public int multiply(int a,int b)
     {
         int answer=a*b;
         return answer;
        }
         public double divide(int a,int b)
     {
         double answer=(double)a/(double)b;
         return answer;
        }
         public int modulus(int a,int b)
     {
         int answer=a%b;
         return answer;
        }
         public int factorial(int a)
     {
         int answer=1;
         for(int i=1;i<=a;i++)
         {
             answer=answer*i;
            
            }
     
         return answer;
        }
       
        public String toString()
    
    {
       return ("Sum: " + add + " Difference: " + subtract + " Product: " + multiply + " Quotient: " + divide + " Remainder: " + modulus);   }
    }
        