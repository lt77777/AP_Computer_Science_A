
/**
 * Write a class, Calc, that has 5 methods: add(), subtract(), multiply(), divide(), and modulus(). 
 * Each should receive two parameters, and return the resulting operation.
Next, create a client, CalcTester, that asks the user for two numbers, 
then uses the class to perform and display the first 4 operations. 
(Ask for 2 other numbers for the modulus() operation.)
After this, add a 6th method to Calc: factorial(), which receives one parameter, 
and returns the factorial(example: factorial of 4 = 4*3*2*1 = 24). 
The method must accomplish this by using a loop.
Test this method from the client.
 * 
 * Lawrence Tsai
 * 06DEC2019
 */
import java.util.Scanner;
public class CalcTester
{
    public static void main(){

        Scanner scanny=new Scanner(System.in);
        System.out.println("What is the first number?");
        int a=scanny.nextInt();
          System.out.println("What is the second number?");
        int b=scanny.nextInt();
       Calc calc=new Calc();
       
        int c=calc.add(a,b);
        int d=calc.subtract(a,b);
        int e=calc.multiply(a,b);
        double f=calc.divide(a,b);
        int g=calc.modulus(a,b);
        System.out.println("Sum: " + c + " Difference: " + d + " Product: " + e+ " Quotient: " + f + " Remainder: " +g);
        System.out.println("What is the third number?");
        int r=scanny.nextInt();
        int sg=calc.factorial(r);
        System.out.println("Factorial: " + sg);
        
    }
    }