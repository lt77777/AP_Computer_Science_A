
/**
 * Assignment #1
Create a CLASS called FamilyClass.
It will require about 10 instance variables…see below to figure out which ones.
Its first method, called setData( ), does not return anything. But it does do the following:
-Asks how many people are in your family
-Asks for the age of each person
-Uses if statements to determine certain information (see below…)
Next, create the following methods. Each should return one value: 
-getAvg - getNumTeens
-getOldest - getNumAdults (adults: age 20+)
-getYoungest - getNumEvens
-getNumKids (age 0-12) - getNumOdds
Next, create a CLIENT called FamilyClient that instantiates 2 different FamilyClass objects.
Demonstrate the calls to each of the methods of the FamilyClass by printing the proper information.
 *
 *Lawrence Tsai
 *22NOV2019
 */
import java.util.Scanner;
public class FamilyClass
{
    Scanner scanny=new Scanner(System.in);
     int max=0;
        int min=10000;
        int avg=0;
        int total=0;
        int kids=0;
        
        int odds=0;
        int teens;
        int adults;
        int even;
        int number;
        int number1;
        public void setData()
        {
             System.out.println("How many people are in your family?");
        number1=scanny.nextInt();
        for(int i=1; i<=number1; i++)
        {
            System.out.println("What is the age of family member number " + i);
            int number=scanny.nextInt();
            if (number>max)
            {
                max=number;
            }
            if(number<min)
            {
                min=number;
            }
            total+=number;
            if (number<=12)
            {
                kids++;
            } 
            if (number>12&&number<20)
            {
                teens++;
            }
            if (number>=20)
            {
                adults++;
            }
            if(number%2==0)
            {

                even++;
            }
            if(number%2==1)
            {

                odds++;
            }
            avg=total/i;
        }
        this.min=min;
        this.max=max;
       this.avg=avg;
        this.total=total;
        this.kids=kids;
        this.avg=avg;
        this.odds=odds;
        this.teens=teens;
        this.adults=adults;
        this.even=even;
    }
    public void Data()
    {
       
       
        
    }
        public int getAvg()
        {
            return avg;
        }
        public int getMin()
        {
            return min;
        }
        public int getMax()
        {
            return max;
        }
        public int getKids()
        {
            return kids;
        }
        public int getTeens()
        {
            return teens;
        }
        public int getAdults()
        {
            return adults;
        }
        public int getOdds()
        {
            return odds;
        }
        public int getEvens()
        {
            return even;
        }
    }