
/**
This project is to demonstrate the HAS-A and IS-A relationships.
Design an Astroknot class with several instance variables including name, weight, fitnessLevel and currentPlanet. 
The Astroknot will also have several actions it can perform. At the minimum he/she should be able to jump, eat, rest and exercise. 
Note that the fitnessLevel will increase along with a decrease in weight when he/she exercises. Rest could also have an influence on the fitness level. 
Similarly when the astroknot Jumps it’s weight , currentPlanet and fitnessLevel will affect the height of the jump. 
For example Dr. Grateful on the moon will be able to jump much higher than Mr. Mela on Earth even though they have similar fitnessLevels;) 
(I know the moon is not a planet!!) Next you will need to create a class called Planet that creates planet objects that have name, diameter, mass and gravity.
Remember all of the variables will need to be private so that they may not be changed.

Finally make a client to demonstrate the different aspects of the Astroknot.
 Send the astroknot to different planets, make them exercise, sleep and jump. Have fun with it!!!
 * Larry Tsai
 * 15DEC2019
 */
import java.util.Scanner;
public class Planet

{
    private String name;
    private double diameter;
    private double mass;
    private double gravity;

    public void setData(){
        Scanner scanny=new Scanner(System.in);
        System.out.println("What planet are you on?");
        String plan=scanny.nextLine();
        plan=plan.toLowerCase();
        if(plan=="mercury")
        {
            mass=0.33*(Math.pow(10,24));
            diameter=4879;
            gravity=3.7;
        }
        if(plan=="venus")
        {
            mass=4.87*(Math.pow(10,24));
            diameter=12104;
            gravity=8.9;
        }
        if(plan=="earth")
        {
            mass=5.97*(Math.pow(10,24));
            diameter=12756;
            gravity=9.8;
        }
        if(plan=="Mars")
        {
            mass=0.642*(Math.pow(10,24));
            diameter=6792;
            gravity=3.7;
        }
        if(plan=="jupiter")
        {
            mass=1898*(Math.pow(10,24));
            diameter=142984;
            gravity=23.1;
        }
        if(plan=="saturn")
        {
            mass=568*(Math.pow(10,24));
            diameter=120536;
            gravity=9;
        }
        if(plan=="uranus")
        {
            mass=86.8*(Math.pow(10,24));
            diameter=51118;
            gravity=8.7;
        }
        if(plan=="neptune")
        {
            mass=102*(Math.pow(10,24));
            diameter=49528;
            gravity=11;
        }

    }
public double retunr
}