
/**
 * Assignment #1
Create a CLASS called FamilyClass.
It will require about 10 instance variables…see below to figure out which ones.
Its first method, called setData( ), does not return anything. But it does do the following:
-Asks how many people are in your family
-Asks for the age of each person
-Uses if statements to determine certain information (see below…)
Next, create the following methods. Each should return one value: 
-getAvg - getNumTeens
-getOldest - getNumAdults (adults: age 20+)
-getYoungest - getNumEvens
-getNumKids (age 0-12) - getNumOdds
Next, create a CLIENT called FamilyClient that instantiates 2 different FamilyClass objects.
 Demonstrate the calls to each of the methods of the FamilyClass by printing the proper information.
 *
 *Lawrence Tsai
 *22NOV2019
 */
public class FamilyClass
{
    
}