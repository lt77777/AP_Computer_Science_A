
/**
 Larry Tsai
 18MAR2020
 */
import java.util.Arrays;
import java.util.List;
public class Sorting
{
    //***  Below is the code for the Bubble Sort  *****
		public static void bubble(int[] a){
		  }
//***  Below is the code for the Insertion Sort  *****
		public static void insertion(int[] a){
		  }
//***  Below is the code for the Selection Sort  *****
		public static void selection(int[] a){
		    
		  }
//***  Below is the code for the Merge Sort  *********
		public static void merge(int[] a){
		  }
//***  Below is the code for the Quick Sort     *******
		public static void quick(int[] a){
		  }
		  public static int [] random (String[]args)
		  {
		     int []random1=new int [50];
		      int number=((int)(Math.random()*(50)+1))+49;
		      for(int i=0; i<random1.length; i++)
		      {
		          if(random1[i]==number)
		          
		          
		      }
		      
		      if (random1.contains(number)){
		      random.add(number);
		  }
		  }
}