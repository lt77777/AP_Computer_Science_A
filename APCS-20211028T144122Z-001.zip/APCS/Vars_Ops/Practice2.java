
/**
 * Write a description of class Practice2 here.
 * 
 * Lawrence Tsai 
 * 09SEP2019
 */
public class Practice2
{
    public static void main() {
        boolean isTrue = false;
        double money = 9999.99;
        System.out.print(money);
        System.out.print(isTrue);
    }
    }
    