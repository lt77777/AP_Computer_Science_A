
/**
 * Write a description of class Practice3 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Practice3
{
    public static void main() {
        String name = "Chen";
        int age = 50;
        int iq = age;
        System.out.print (name);
        System.out.print (age);
        System.out.print (iq);
    }
}
    