
/**
 * A yield sign encloses the word YIELD within a triangle. Write a program that displays a yield sign. (slashes (/\) must be used to represent the sides of the triangle)
 * 
 * Larry Tsai
 * 13SEP2019
 */
public class Yield
{
    public static void main () {
        
        System.out.println(" _____________________");
        System.out.println(" \\  ______________   /");
        System.out.println("  \\ \\            /  /");
        System.out.println("   \\ \\   YIELD  /  /");
        System.out.println("    \\ \\        /  /");
        System.out.println("     \\ \\      /  / " );
        System.out.println("      \\ \\    /  /");
        System.out.println("       \\ \\  /  /");
        System.out.println("        \\ \\/  / ");
        System.out.println("         \\   /");
        System.out.println("          \\ /");
        System.out.println("           \\/");
       
        
        
        
        
        
        
        

    
    }
}